INSERT INTO books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (1, N'Kay�p Zaman�n �zinde', N'M. Proust', N'roman', 129.90, 25, 1913, '2025-08-20');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (2, N'Simyac�', N'P. Coelho', N'roman', 89.50, 40, 1988, '2025-08-21');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (3, N'Sapiens', N'Y. N. Harari', N'tarih', 159.00, 18, 2011, '2025-08-25');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (4, N'�nce Memed', N'Y. Kemal', N'roman', 99.90, 12, 1955, '2025-08-22');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (5, N'K�rl�k', N'J. Saramago', N'roman', 119.00, 7, 1995, '2025-08-28');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (6, N'Dune', N'F. Herbert', N'bilim', 149.00, 30, 1965, '2025-09-01');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (7, N'Hayvan �iftli�i', N'G. Orwell', N'roman', 79.90, 55, 1945, '2025-08-23');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (8, N'1984', N'G. Orwell', N'roman', 99.00, 35, 1949, '2025-08-24');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (9, N'Nutuk', N'M. K. Atat�rk', N'tarih', 139.00, 20, 1927, '2025-08-27');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (10, N'K���k Prens', N'A. de Saint-Exup�ry', N'�ocuk', 69.90, 80, 1943, '2025-08-26');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (11, N'Ba�lang��', N'D. Brown', N'roman', 109.00, 22, 2017, '2025-09-02');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (12, N'Atomik Al��kanl�klar', N'J. Clear', N'ki�isel geli�im', 129.00, 28, 2018, '2025-09-03');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (13, N'Zaman�n K�sa Tarihi', N'S. Hawking', N'bilim', 119.50, 16, 1988, '2025-08-29');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (14, N'�eker Portakal�', N'J. M. de Vasconcelos', N'roman', 84.90, 45, 1968, '2025-08-30');

INSERT INTO Books (book_id, title, author, genre, price, stock_qty, published_year, added_at)
VALUES (15, N'Bir �dam Mahk�munun Son G�n�', N'V. Hugo', N'roman', 74.90, 26, 1829, '2025-08-31');